<style>
  .tes {
    transition: 0.2s;
  }
  .tes:hover {
    transform: scale(0.99);
    transition: 0.2s;
  }
  article {
    position: relative;
  }
  .bottom-left {
    position: absolute;
    bottom: 20;
    left: 30;
  }
</style>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?= $judul; ?></title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<?= base_url('assets/frontend/'); ?>assets/img/favicon.png" rel="icon">
  <link href="<?= base_url('assets/frontend/'); ?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<?= base_url('assets/frontend/'); ?>assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Selecao
  * Template URL: https://bootstrapmade.com/selecao-bootstrap-template/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="<?= base_url('home/'); ?>" class="logo d-flex align-items-center">
          <h1 class="sitename"><?= $konfig->judul_website; ?></h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?= base_url('home/'); ?>">Beranda</a></li>
          <li><a href="#portfolio">Konten</a></li>
          <li class="dropdown"><a href="#">Kategori <i class="bi bi-chevron-down toggle-dropdown"></i></a>
          <ul>
              <?php foreach($kategori as $kate){ ?>
                <li>
                  <a href="<?= base_url('home/kategori/'.$kate['id_kategori']); ?>">
                    <?= $kate['nama_kategori']; ?>
                  </a>
                </li>
              <?php } ?>
            </ul>
          </li>
          <li style="margin-right: 5%;"><a href="#footer">Kontak</a></li>
          <a href="<?= base_url('auth'); ?>" class="btn btn-danger px-4">Login</a>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section custom-background">

    <div id="hero-carousel" data-bs-interval="5000" class="container carousel carousel-fade mt-2" data-bs-ride="carousel">

        <!-- Slide 1 -->
        <!-- <div class="carousel-container">
          <h2 class="animate__animated animate__fadeInDown">Welcome to <span>Selecao</span></h2>
          <p class="animate__animated animate__fadeInUp">Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
        </div> -->
        <?php if (empty($konten)) { ?>
            <div class="carousel-container mt-5">
              <h2 class="animate__animated animate__fadeInDown" style="color: white;">Upss, sepertinya belum ada berita terbaru.</h2>
              <p class="animate__animated animate__fadeInUp" style="color: white;">Nantikan update selanjutnya!</p>
            </div>
        <?php } else { ?>
          <?php $no=1; foreach($konten as $kon) { ?>
            <div class="carousel-item <?php if($no==1){echo 'active';} ?>">
              <div class="carousel-container mb-5">
                <a href="<?= base_url('home/artikel/'.$kon['slug']); ?>">
                  <img src="<?= base_url('assets/upload/konten/'.$kon['foto']); ?>" class="animate__animated animate__fadeInUp" style="width: 900px; height: 400px; border-radius: 10px; box-shadow: 0px 8px 20px black; margin-top: 30px;" alt="">
                </a>
              </div>
            </div>
          <?php $no++; } ?>
          <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
          </a>

          <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
          </a>

        <?php } ?>
      
    </div>

      <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none" style="margin-top: 20px; z-index: 3;">
        <defs>
          <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
        </defs>
        <g class="wave1">
          <use xlink:href="#wave-path" x="50" y="3"></use>
        </g>
        <g class="wave2">
          <use xlink:href="#wave-path" x="50" y="0"></use>
        </g>
        <g class="wave3">
          <use xlink:href="#wave-path" x="50" y="9"></use>
        </g>
      </svg>

    </section><!-- /Hero Section -->

    <!-- Portfolio Section -->
    <section id="portfolio" class="blog-posts section light-background" style="border-bottom: rgb(176, 176, 176) 1px solid;">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Konten</h2>
        <p>Baca berita <?= $datak->nama_kategori; ?></p>
        <?php if (empty($konten)) { ?>
          <p style="font-weight: bold; color: red; margin-top: 100px;">Berita tidak ditemukan.</p>
          <a href="<?= base_url('home/'); ?>">Kembali ke beranda?</a>
        <?php } ?>
      </div><!-- End Section Title -->

      <div class="container">
        <div class="row gy-4">
          <?php foreach($konten as $kon) { ?>
          <div class="col-lg-4">
            <article>

              <div class="post-img">
                <a href="<?= base_url('home/artikel/'.$kon['slug']); ?>">
                <img src="<?= base_url('assets/upload/konten/' . $kon['foto']); ?>" alt="" class="" style="width: 100%; height: 65%;">
                </a>
              </div>

              <h2 class="title">
                <a href="<?= base_url('home/artikel/'.$kon['slug']); ?>"><?= $kon['judul']; ?></a>
              </h2>
              <p class="post-date bottom-left">
                <?= $kon['tanggal'] ?>
              </p>
            </article>
          </div><!-- End post list item -->
          <?php } ?>
        </div>
      </div>

    </section><!-- /Portfolio Section -->

  </main>

  <footer id="footer" class="footer light-background">
    <div class="container">
      <h3 class="sitename" style="margin-top: 100px;"><?= $konfig->judul_website; ?></h3>
      <p><?= $konfig->profil_website; ?></p>
      <div class="social-links d-flex justify-content-center">
        <a href="https://www.google.com/maps/search/<?= $konfig->alamat; ?>"><i class="bi bi-pin"></i></a>
        <a href="mailto:<?= $konfig->email; ?>"><i class="bi bi-envelope"></i></a>
        <a href="https://wa.me/<?= $konfig->no_wa; ?>"><i class="bi bi-phone"></i></a>
        <a href="https://facebook.com/<?= $konfig->facebook; ?>"><i class="bi bi-facebook"></i></a>
        <a href="https://instagram.com/<?= $konfig->instagram; ?>"><i class="bi bi-instagram"></i></a>
      </div>
      <div class="container">
        <div class="copyright">
          <span>Copyright</span> <strong class="px-1 sitename"><?= $konfig->judul_website; ?></strong> <span>All Rights Reserved</span>
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you've purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
          Designed by <a href="https://github.com/ode-arstiko/">Ode</a> Distributed By <a href="https://smkn2kra.sch.id/">Smkn2Kra</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/aos/aos.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="<?= base_url('assets/frontend/'); ?>assets/js/main.js"></script>

</body>

</html>