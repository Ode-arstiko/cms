<style>
    .custom-file .lab1 {
    background-color: #007bff;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    display: inline;
    }
    .custom-file .lab1:hover {
        background-color: #0073ee;
    }
    .lab2 {
        background-color: white;
        border: 1px blue solid;
        border-radius: 5px;
        padding: 9px 19px;
        display: inline;
    }

    .custom-file2 .lab2 {
    background-color: #007bff;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    display: inline;
    }
    .custom-file2 .lab2:hover {
        background-color: #0073ee;
    }
    .lab3 {
        background-color: white;
        border: 1px blue solid;
        border-radius: 5px;
        padding: 9px 19px;
        display: inline;
    }
</style>





<div id="hilang"> 
  <?= $this->session->flashdata('alert')?>
</div>
<div class="col-lg-12 col-md-124">
  <div class="mt-1 mb-3">
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalCenter">
      Tambah Konten
    </button>
    <!-- Modal -->
    <div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <form action="<?= base_url('admin/konten/simpan') ?>" method="post" enctype="multipart/form-data">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalCenterTitle">Tambah Konten</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col mb-6">
                <label class="form-label">Judul</label>
                <input type="text" class="form-control" placeholder="Masukan judul konten" name="judul" required>
              </div>
            </div>
            <div class="row">
              <div class="col mb-6">
                <label class="form-label">Kategori</label>
                <select name="id_kategori" class="form-control">
                    <?php foreach($kategori as $aa) { ?>
                        <option value=" <?= $aa['id_kategori' ] ?> "><?= $aa['nama_kategori' ] ?></option>
                    <?php } ?>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col mb-6">
                <label class="form-label">Keterangan</label>
                <textarea name="keterangan" class="form-control" placeholder="Masukan keterangan konten"></textarea>
              </div>
            </div>
            <div class="row">
              <div class="col mb-6 custom-file">
                <label class="form-label mb-3">Foto</label><br>
                <input type="file" name="foto" class="form-control"
                accept="image/png, image/jpeg" id="fileInput" hidden>
                <label for="fileInput" id="customLabel" class="lab1">Pilih file</label>
                <label for="" class="lab2" id="labs2">Foto kosong</label>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-warning">Simpan</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="card">
    <h5 class="card-header">Daftar Konten</h5>
    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Kategori Konten</th>
                    <th>Tanggal</th>
                    <th>Kreator</th>
                    <th>Foto</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $no=1; foreach($konten as $aa) { ?>
                <tr>
                    <td> <?= $no; ?></td>
                    <td> <?= $aa['judul' ] ?></td>
                    <td> <?= $aa['nama_kategori' ] ?></td>
                    <td> <?= $aa['tanggal' ] ?></td>
                    <td> <?= $aa['nama' ] ?></td>
                    <td>
                    <!-- Gambar Thumbnail -->
                    <div class="mt-2 mb-2">
                    <button type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#imageModal<?= $no; ?>">
                      Tampilkan gambar
                    </button>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="imageModal<?= $no; ?>" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="imageModalLabel">Tampilan Gambar</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body" style="display: flex; justify-content: center; align-items: center;">
                                        <img src="<?= base_url('assets/upload/konten/' . $aa['foto']); ?>" alt="Gambar" class="img-fluid" id="modalImage" style="width: 400px; border-radius: 10px; box-shadow: 2px 2px 10px black; max-width: 400px; min-width: 200px;">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </td>
                    <td>
                    <a href=" <?php echo site_url('admin/konten/delete_data/'.$aa['foto']);?>" class="btn btn-sm btn-danger" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')"><span class="tf-icons bx bx-trash"></span></a>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#konten<?= $no; ?>"><span class="tf-icons bx bx-edit"></span>
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="konten<?= $no; ?>" tabindex="-1" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <form action="<?= base_url('admin/konten/update') ?>" method="post" enctype="multipart/form-data">
                              <input type="hidden" name="nama_foto" value="<?= $aa['foto'] ?>">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="modalCenterTitle"><?= $aa['judul'] ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                <div class="row">
                                  <div class="col mb-6">
                                    <label class="form-label">Judul</label>
                                    <input type="text" class="form-control" value="<?= $aa['judul'] ?>" name="judul" >
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col mb-6">
                                    <label class="form-label">Kategori</label>
                                    <select name="id_kategori" class="form-control">
                                        <?php foreach($kategori as $uu) { ?>
                                            <option <?php if($uu['nama_kategori'] == $aa['nama_kategori']){ echo"selected";} ?> value=" <?= $uu['id_kategori'] ?> ">
                                            <?= $uu['nama_kategori' ] ?></option>
                                        <?php } ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="row">
                                    <div class="col mb-6">
                                        <label class="form-label">Keterangan</label>
                                        <textarea name="keterangan" class="form-control"><?php echo isset($aa['keterangan']) ? $aa['keterangan'] : ''; ?></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                <div class="col mb-6 custom-file2">
                                  <label class="form-label mb-3">Foto</label><br>
                                  <input type="file" name="foto" class="form-control"
                                  accept="image/png, image/jpeg" id="fileInput2" hidden>
                                  <label for="fileInput2" id="customLabel2" class="lab2">Pilih file</label>
                                  <label for="" class="lab3" id="labs3">Foto kosong</label>
                                </div>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-warning">Simpan</button>
                              </div>
                            </div>
                            </form>
                          </div>
                        </div>
                    </td>
                </tr>
                <?php $no++;} ?>
            </tbody>
        </table>
    </div>
</div>



<script>
  const fileInput = document.getElementById('fileInput');
  const customLabel = document.getElementById('labs2');

  fileInput.addEventListener('change', function () {
      const fileName = fileInput.files[0] ? fileInput.files[0].name : "Pilih File";
      customLabel.textContent = fileName;
      customLabel.style.color = "blue";
  });


</script>
<script>
    const inputFile = document.getElementById('fileInput2');
    const labelCustom = document.getElementById('labs3');

    inputFile.addEventListener('change', function () {
        const nameFile = inputFile.files[0] ? inputFile.files[0].name : "Pilih File";
        labelCustom.textContent = nameFile;
        labelCustom.style.color = "blue";
    });
</script>