<style>
    .custom-file .lab1 {
    background-color: #007bff;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    display: inline;
    }
    .custom-file .lab1:hover {
        background-color: #0073ee;
    }
    .lab2 {
        background-color: white;
        border: 1px blue solid;
        border-radius: 5px;
        padding: 9px 19px;
        display: inline;
    }

</style>

<div id="hilang"> 
  <?= $this->session->flashdata('alert')?>
</div>
<div class="col-xl-12">
    <div class="card">
        <form action="<?= base_url('admin/caraousel/simpan') ?>" method="post" enctype='multipart/form-data'>
        <h5 class="card-header">File input</h5>
        <div class="col mb-6" style="margin-left: 25px;">
            <label for="" class="form-label">Judul</label>
            <input type="text" class="form-control" placeholder="Judul caraousel" name="judul" required>
        </div>
        <div class="card-body custom-file">
            <label for="formFile" class="form-label" style="margin-bottom: 20px;">Masukan Foto</label><br>
            <input type="file" name="foto" class="form-control" accept="image/png, image/jpeg" id="fileInput" hidden required>
            <label for="fileInput" id="customLabel" class="lab1">Pilih foto</label>
            <label for="" class="lab2" id="labs2">Foto kosong</label>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-warning">Save</button>
          </div>
        </form>
    </div>
</div>
<?php foreach ($caraousel as $aa) { ?>
<div class="col-md-12 mb-3 mt-4">
    <div class="card h-100">
      <img class="card-img-top" src="<?= base_url('assets/upload/caraousel/' . $aa['foto']); ?>">
      <div class="card-body">
        <h5 class="card-title"><?= $aa['judul'] ?></h5>
        <a href=" <?php echo site_url('admin/caraousel/delete_caraousel/'.$aa['foto']);?>" class="btn btn-outline-warning" onClick="return confirm('Apakah anda yakin ingin menghapus caraousel ini?')">Hapus caraousel</a>
      </div>
    </div>
</div>
<?php } ?>

<script>
  const fileInput = document.getElementById('fileInput');
  const customLabel = document.getElementById('labs2');

  fileInput.addEventListener('change', function () {
      const fileName = fileInput.files[0] ? fileInput.files[0].name : "Pilih File";
      customLabel.textContent = fileName;
      customLabel.style.color = "blue";
  });
</script>