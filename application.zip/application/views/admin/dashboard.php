<style>
    .gambar-tengah {
        margin-left: auto;
        margin-right: auto;
        margin-bottom: 20px;
        width: 100%;
        border-radius: 10px;
    }
    .container-kartu {
        display: flex;
        justify-content: space-between; /* Mengatur jarak antar elemen */
        gap: 20px; /* Jarak antara elemen */
    }
    .teks { 
        display: flex;
        justify-content: space-between; /* Mengatur jarak antara teks kiri dan kanan */
    }
</style>

<div class="container-kartu">
<?php foreach($konten as $kon) { ?>
    <div class="card" style="width: 20rem;">
        <div class="card-body">
            <h4 class="card-text"><b>Konten terbaru anda</b></h4>
            <img src="<?= base_url('assets/upload/konten/' . $kon['foto']); ?>" class="gambar-tengah" alt="gambar">
            <p class="card-text"><b><?= substr($kon['judul'], 0, 40)."..." ?></b></p>
            <p class="card-text teks">Kategori <span><?= $kon['nama_kategori']; ?></span></p>
            <p class="card-text teks">Ditambahkan Pada <span><?= $kon['tanggal']; ?></span></p>
            <p class="card-text teks">Ditambahkan Oleh <span><?= $kon['nama']; ?></span></p>
            <a href="<?= base_url('admin/home/artikel/').$kon['slug'] ?>"><button class="btn btn-warning">Buka konten</button></a>
        </div>
    </div>
<?php } ?>
    <div class="card" style="width: 20rem;">
        <div class="card-body">
            <h4 class="card-text"><b>Analisa website</b></h4>
            <p class="card-text">Konten saat ini</p>
            <h2 style="margin-top: -15px;"><b><?= $total_konten; ?></b></h2><br><br>
            <hr>
            <p class="card-text teks">Jumlah Kontributor <span><?= $total_kontri; ?></span></p>
            <p class="card-text teks">Total Pengguna <span><?= $total_pengguna; ?></span></p>
        </div>
    </div>

    <div class="card" style="width: 20rem;">
        <div class="card-body">
            <h4 class="card-text" style="margin-bottom: 15px;"><b>Pesan & Masukan</b></h4>
            <?php foreach($pesan as $pes){ ?>
            <p class="card-text"><?= $pes['nama']; ?> | <?= $pes['tanggal_pesan']; ?></p>
            <p class="card-text" style="margin-top: -20px;"><?= $pes['email']; ?></p>
            <p class="card-text" style="color: #29333d;">Pesan : <?= substr($pes['pesan'], 0, 25) . "..." ?></p>
            <hr>
            <?php } ?>
            <a href="<?= base_url('admin/pesan'); ?>"><button class="btn btn-warning">Lihat semua pesan</button></a>
        </div>
    </div>
    
</div>