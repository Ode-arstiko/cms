<div id="hilang"> 
  <?= $this->session->flashdata('alert')?>
</div>
<form action="<?= base_url('admin/konfigurasi/update') ?>" method="post">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalCenterTitle">Konfigurasi</h5>
          </div>
          <div class="modal-body">
            <div class="row">
              <label for="" class="form-label" style="margin-bottom: 8px;">Judul website</label>
              <div class="col mb-6">
                <input type="text" class="form-control" placeholder="Judul website" name="judul_website" value="<?= $konfig->judul_website; ?>" required />
              </div>
            </div>
            <div class="row mt-3">
            <label for="" class="form-label" style="margin-bottom: 8px;">Profil website</label>
              <div class="col mb-6">
                <textarea name="profil_website" class="form-control" placeholder="Profil website"><?= $konfig->profil_website; ?></textarea>
              </div>
            </div>
            <div class="row mt-3">
            <label for="" class="form-label" style="margin-bottom: 8px;">Instagram</label>
              <div class="col mb-6">
                <input type="text" class="form-control" placeholder="Instagram" name="instagram" value="<?= $konfig->instagram; ?>" required />
              </div>
            </div>
            <div class="row mt-3">
            <label for="" class="form-label" style="margin-bottom: 8px;">Facebook</label>
              <div class="col mb-6">
                <input type="text" class="form-control" placeholder="Facebook" name="facebook" value="<?= $konfig->facebook; ?>" required />
              </div>
            </div>
            <div class="row mt-3">
            <label for="" class="form-label" style="margin-bottom: 8px;">Email</label>
              <div class="col mb-6">
                <input type="text" class="form-control" placeholder="E-mail" name="email" value="<?= $konfig->email; ?>" required />
              </div>
            </div>
            <div class="row mt-3">
            <label for="" class="form-label" style="margin-bottom: 8px;">Alamat rumah</label>
              <div class="col mb-6">
                <input type="text" class="form-control" placeholder="Masukan alamat" name="alamat" value="<?= $konfig->alamat; ?>" required />
              </div>
            </div>
            <div class="row mt-3">
            <label for="" class="form-label" style="margin-bottom: 8px;">No. whatsapp</label>
              <div class="col mb-6">
                <input type="text" class="form-control" placeholder="No. Whatsapp" name="no_wa" value="<?= $konfig->no_wa; ?>" required />
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-warning">Simpan</button>
          </div>
        </div>
        </form>