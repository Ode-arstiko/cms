<style>
    .teks { 
        display: flex;
        justify-content: space-between; /* Mengatur jarak antara teks kiri dan kanan */
    }
</style>

<h1><b>Pesan pengguna</b></h1>
<div class="card" style="width: 100%;">
        <div class="card-body">
        <?php foreach($pesan as $pes){ ?>
            <p class="card-text teks">Pengirim : <?= $pes['nama']; ?><span><?= $pes['tanggal_pesan']; ?></span></p>
            <p class="card-text" style="margin-top: -20px;">E-mail : <?= $pes['email']; ?></p>
            <p class="card-text" style="color: #29333d;">Pesan : <?= $pes['pesan'] ?></p>
            <hr>
            <?php } ?>
        </div>
    </div>