<style>
  .tes {
    transition: 0.2s;
  }
  .tes:hover {
    transform: scale(0.99);
    transition: 0.2s;
  }
</style>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?= $judul; ?></title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<?= base_url('assets/frontend/'); ?>assets/img/favicon.png" rel="icon">
  <link href="<?= base_url('assets/frontend/'); ?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url('assets/frontend/'); ?>assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<?= base_url('assets/frontend/'); ?>assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Selecao
  * Template URL: https://bootstrapmade.com/selecao-bootstrap-template/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="<?= base_url('admin/Home'); ?>" class="logo d-flex align-items-center">
          <h1 class="sitename"><?= $konfig->judul_website; ?></h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?= base_url('admin/Home') ?>" class="active">Dashboard</a></li>
          <li><a href="#portfolio">Berita</a></li>
          <li style="margin-right: 5%;"><a href="#footer">Kontak</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section custom-background">

      <div id="hero-carousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">
          <div class="carousel-container">
            <h2 class="animate__animated animate__fadeInDown" style="color: white;">Apa itu <span><?= $konfig->judul_website; ?>?</span></h2>
            <p class="animate__animated animate__fadeInUp">BeritaKita adalah platform gratis yang dirancang untuk memberikan akses cepat ke informasi terkini dari berbagai kategori, mulai dari berita politik, kriminalitas, bencana alam, hingga olahraga. Dengan antarmuka yang menarik dan mudah digunakan, website ini menjadi solusi ideal bagi siapa saja yang ingin tetap terinformasi kapan saja dan dimana saja.</p>
          </div>
      </div>

      <!-- <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none" style="margin-top: 20px;">
        <defs>
          <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
        </defs>
        <g class="wave1">
          <use xlink:href="#wave-path" x="50" y="3"></use>
        </g>
        <g class="wave2">
          <use xlink:href="#wave-path" x="50" y="0"></use>
        </g>
        <g class="wave3">
          <use xlink:href="#wave-path" x="50" y="9"></use>
        </g>
      </svg> -->

    </section><!-- /Hero Section -->

    <!-- Portfolio Section -->
    <section id="portfolio" class="portfolio section light-background" style="border-bottom: rgb(176, 176, 176) 1px solid;">

      <!-- Detail Start -->
    <div class="container section-title" data-aos="fade-up">
      <div class="row pt-5">
        <div class="col-lg-8">
          <div class="d-flex flex-column text-left mb-3">
            <h2>Halaman Detail Berita</h2>
            <p style="margin-bottom: 40px;"><?= $konten->judul; ?></p>
            <div class="d-flex">
                <h5 style="margin-right: 20px;"><i class="bi bi-person"></i><?= $konten->nama; ?></h5>
                <h5><i class="bi bi-folder"></i> <?= $konten->nama_kategori; ?></h5>
            </div>
          </div>
          <div class="mb-5">
            <img
              class="img-fluid rounded w-100 mb-4"
              src="<?= base_url('assets/upload/konten/'.$konten->foto); ?>"
            />
            <?=
                $jumlah_titik = 0;
                $output = "";

                for ($i = 0; $i < strlen($konten->keterangan); $i++) {
                    $output .= $konten->keterangan[$i];
                    if ($konten->keterangan[$i] === ".") {
                        $jumlah_titik++;

                        if ($jumlah_titik % 3 == 0) {
                            $output .= "<br><br>";
                        }
                    }
                }

                echo "__".$output;
            ?>
          </div>
        </div>
      </div>
    </div>
    <!-- Detail End -->

    </section><!-- /Portfolio Section -->

  </main>

  <footer id="footer" class="footer light-background">
    <div class="container">
      <h3 class="sitename" style="margin-top: 100px;"><?= $konfig->judul_website; ?></h3>
      <p><?= $konfig->profil_website; ?></p>
      <div class="social-links d-flex justify-content-center">
        <a href="https://www.google.com/maps/search/<?= $konfig->alamat; ?>"><i class="bi bi-pin"></i></a>
        <a href="mailto:<?= $konfig->email; ?>"><i class="bi bi-envelope"></i></a>
        <a href="https://wa.me/<?= $konfig->no_wa; ?>"><i class="bi bi-phone"></i></a>
        <a href="https://facebook.com/<?= $konfig->facebook; ?>"><i class="bi bi-facebook"></i></a>
        <a href="https://instagram.com/<?= $konfig->instagram; ?>"><i class="bi bi-instagram"></i></a>
      </div>
      <div class="container">
        <div class="copyright">
          <span>Copyright</span> <strong class="px-1 sitename"><?= $konfig->judul_website; ?></strong> <span>All Rights Reserved</span>
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you've purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
          Designed by <a href="https://github.com/ode-arstiko/">Ode</a> Distributed By <a href="https://smkn2kra.sch.id/">Smkn2Kra</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/aos/aos.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url('assets/frontend/'); ?>assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="<?= base_url('assets/frontend/'); ?>assets/js/main.js"></script>

</body>

</html>