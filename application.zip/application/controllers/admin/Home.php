<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function __construct(){
        parent::__construct();
		if($this->session->userdata('level')==NULL) {
			redirect('auth');
		}
    }
	public function index(){
		$this->db->from('konfigurasi');
        $konfig = $this->db->get()->row();
		$this->db->from('kategori');
        $kategori = $this->db->get()->result_array();
		$this->db->from('konten');
		$total = $this->db->count_all('konten');
		$this->db->from('user');
		$total_pengguna = $this->db->count_all('user');
		$this->db->from('user');
		$this->db->where('level', "Kontributor");
		$total_kontri = $this->db->count_all_results();
		$this->db->from('pesan_pengguna');
		$this->db->limit(3);
		$pesan = $this->db->get()->result_array();
        $this->db->from('konten a');
        $this->db->join('kategori b', 'a.id_kategori = b.id_kategori', 'left');
        $this->db->join('user c', 'a.username = c.username', 'left');
        $this->db->order_by('id_konten', 'DESC');
		$this->db->limit(1);
        $konten = $this->db->get()->result_array();

		$data = array(
			'judul_halaman' => "Halaman Dashboard",
			'konfig' => $konfig,
			'kategori' => $kategori,
			'konten' => $konten,
			'total_konten' => $total,
			'total_kontri' => $total_kontri,
			'total_pengguna' => $total_pengguna,
			'pesan' => $pesan
		);
		$this->template->load('template_admin','admin/dashboard',$data);	
	}

	public function artikel($id){
		$this->db->from('konfigurasi');
    	$konfig = $this->db->get()->row();

    	$this->db->from('kategori');
    	$kategori = $this->db->get()->result_array();

    	$this->db->select('a.id_konten, a.judul, a.slug, b.nama_kategori, c.nama, a.tanggal, a.foto, a.keterangan'); // Pilih kolom yang diperlukan
    	$this->db->from('konten a');
    	$this->db->join('kategori b', 'a.id_kategori = b.id_kategori', 'left');
    	$this->db->join('user c', 'a.username = c.username', 'left');
    	$this->db->where('slug', $id);
    	$this->db->distinct();
		$konten = $this->db->get()->row();
    	$data = array (
    	    'judul' => $konten->judul." | ArtikelKu",
    	    'konfig' => $konfig,
    	    'kategori' => $kategori,
    	    'konten' => $konten
    	);
    	$this->load->view('admin/detail_admin', $data);
	}
}
