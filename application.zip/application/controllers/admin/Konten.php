<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Konten extends CI_Controller {
    public function __construct(){
        parent::__construct();
		if($this->session->userdata('level')==NULL) {
			redirect('auth');
		}
    }

	public function index() {
		$this->db->from('konfigurasi');
        $konfig = $this->db->get()->row();
		// Ambil kategori
		$this->db->from('kategori');
		$this->db->order_by('nama_kategori', 'ASC');
		$kategori = $this->db->get()->result_array();
	
		// Ambil konten dengan join
		$this->db->select('a.id_konten, a.judul, b.nama_kategori, c.nama, a.tanggal, a.foto, a.keterangan'); // Pilih kolom yang diperlukan
		$this->db->from('konten a');
		$this->db->join('kategori b', 'a.id_kategori = b.id_kategori', 'left');
		$this->db->join('user c', 'a.username = c.username', 'left');
		$this->db->order_by('a.tanggal', 'DESC');
		$this->db->distinct(); // Pastikan hasil yang diambil unik
		$konten = $this->db->get()->result_array();
	
		// Siapkan data untuk tampilan
		$data = array(
			'konfig' => $konfig,
			'judul_halaman' => 'Halaman Konten',
			'kategori'      => $kategori,
			'konten'        => $konten
		);
	
		// Load tampilan
		$this->template->load('template_admin', 'admin/konten_index', $data);
	}

	// public function index(){
	// 	$this->db->from('kategori');
	// 	$this->db->order_by('nama_kategori','ASC');
    //     $kategori = $this->db->get()->result_array();

	// 	$this->db->from('konten a');
	// 	$this->db->join('kategori b','a.id_kategori=b.id_kategori','left');
	// 	$this->db->join('user c','a.username=c.username','left');
	// 	$this->db->order_by('tanggal','DESC');
	// 	$konten = $this->db->get()->result_array();
	// 	$data = array(
	// 		'judul_halaman' => 'Halaman Konten',
	// 		'kategori'	    => $kategori,
	// 		'konten'	    => $konten
	// 	);
	// 	$this->template->load('template_admin','admin/konten_index',$data);
	// }
	
	public function simpan() {
		$namafoto = date('YmdHis').'.jpg';
		$config['upload_path']      = 'assets/upload/konten/';
		$config['max_size' ]        = 500 * 1024; //3 * 1024 * 1024; //3Mb; 0=unlimited
		$config['file_name']        = $namafoto;
		$config['allowed_types']	= '*';
		$this->load->library('upload', $config);
			if($_FILES['foto']['size'] >= 500* 1024){
			$this->session->set_flashdata('alert','
				<div class="alert alert-danger alert-dismissible mb-4" role="alert">
				Ukuran foto terlalu besar, upload ulang foto dengan ukuran yang kurang dari 500 KB.
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				</div>
				');
		redirect('admin/konten'.$this->input->post('kode_produk'));
		} elseif( ! $this->upload->do_upload('foto')){
			$error = array('error' => $this->upload->display_errors());
		} else{
			$data = array('upload_data' => $this->upload->data());
		}

		$this->db->from('konten');
		$this->db->where('judul',$this->input->post('judul'));
		$cek = $this->db->get()->result_array();
		if($cek<>NULL) {
			$this->session->set_flashdata('alert', '
			<div class="alert alert-danger alert-dismissible mb-4" role="alert">
			Judul Konten sudah ada
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>'
			);
			redirect('admin/konten');
		}
        $data = array(
            'judul' => $this->input->post('judul'),
            'id_kategori' => $this->input->post('id_kategori'),
            'keterangan' => $this->input->post('keterangan'),
            'tanggal' => date('Y-m-d'),
            'foto' => $namafoto,
            'username' => $this->session->userdata('username'),
            'slug' => str_replace(' ','-',$this->input->post('judul'))
        );
		$this->db->insert('konten',$data);
		$this->session->set_flashdata('alert', '
		<div class="alert alert-info alert-dismissible mb-4" role="alert">
		Berhasil menambahkan konten
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>'
		);
		redirect('admin/konten');
	}
	public function update() {
		$namafoto = $this->input->post('nama_foto');
		$config['upload_path']      = 'assets/upload/konten/';
		$config['max_size' ]        = 500 * 1024; //3 * 1024 * 1024; //3Mb; 0=unlimited
		$config['file_name']        = $namafoto;
		$config['overwrite']        = true;
		$config['allowed_types']	= '*';
		$this->load->library('upload', $config);
			if($_FILES['foto']['size'] >= 500* 1024){
			$this->session->set_flashdata('alert','
				<div class="alert alert-danger alert-dismissible mb-4" role="alert">
				Ukuran foto terlalu besar, upload ulang foto dengan ukuran yang kurang dari 500 KB.
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				</div>
				');
		redirect('admin/konten'.$this->input->post('kode_produk'));
		} elseif( ! $this->upload->do_upload('foto')){
			$error = array('error' => $this->upload->display_errors());
		} else{
			$data = array('upload_data' => $this->upload->data());
		}
        $data = array(
            'judul' => $this->input->post('judul'),
            'id_kategori' => $this->input->post('id_kategori'),
            'keterangan' => $this->input->post('keterangan'),
            'slug' => str_replace(' ','-',$this->input->post('judul'))
        );
		$where = array(
			'foto'		=> $this->input->post('nama_foto')
		);
		$this->db->update('konten',$data,$where);
		$this->session->set_flashdata('alert', '
		<div class="alert alert-info alert-dismissible mb-4" role="alert">
		Berhasil memperbarui konten
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>'
		);
		redirect('admin/konten');
	}
	public function delete_data($id) {
		$filename=FCPATH.'/assets/upload/konten/'.$id;
			if (file_exists($filename)){
				unlink("./assets/upload/konten/".$id);
			}
		$where = array(
			'foto'	=> $id
		);
		$this->db->delete('konten', $where);
		$this->session->set_flashdata('alert', '
		<div class="alert alert-info alert-dismissible mb-4" role="alert">
		Berhasil menghapus konten
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>'
		);
		redirect('admin/konten');
	}
	public function method() {
		$konten_id = $this->input->post('id_konten');
		$this->db->from('konten');
		$this->db->order_by($konten_id);
		$id_konten = $this->db->get()->result_array();

		
		if ($konten_id == $id_konten) {
			echo '<img src="' . base_url('assets/upload/konten/' . $data['foto']) . '" alt="Gambar" class="img-fluid" id="modalImage">';
		}
	}
}
