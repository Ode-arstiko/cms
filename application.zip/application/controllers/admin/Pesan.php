<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesan extends CI_Controller {
    public function __construct(){
        parent::__construct();
		$this->load->model('User_model');
		if($this->session->userdata('level')<>'Admin') {
			redirect('auth');
		}
    }
	public function index(){
        $this->db->from('konfigurasi');
        $konfig = $this->db->get()->row();
		$this->db->from('pesan_pengguna');
        $pesan = $this->db->get()->result_array();

		$data = array(
			'konfig' => $konfig,
			'judul_halaman' => 'Halaman Pesan & Masukan',
			'pesan' => $pesan
		);
		$this->template->load('template_admin','admin/pesan_index',$data);
	}
}
